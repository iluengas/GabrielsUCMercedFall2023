select c_mktsegment
from customer
order by c_mktsegment;
