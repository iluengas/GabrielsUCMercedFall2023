select s_phone
from supplier
order by s_phone;
