select count(*) from supplier;
