select count(*) from customer;
