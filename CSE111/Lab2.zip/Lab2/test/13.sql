select n_name
from nation
where n_regionkey = 3
order by n_name;
