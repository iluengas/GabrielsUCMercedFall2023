select count(*) from partsupp;
