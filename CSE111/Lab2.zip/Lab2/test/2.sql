select count(*) from nation;
