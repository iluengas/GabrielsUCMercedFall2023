.mode "csv"
.separator "|"
.headers off

.import data/customer.tbl customer
.import data/lineitem.tbl lineitem
.import data/nation.tbl nation
.import data/orders.tbl orders
.import data/part.tbl part
.import data/partsupp.tbl partsupp
.import data/region.tbl region
.import data/supplier.tbl supplier