.headers on
-- 1. How many customers and suppliers are in every nation from AMERICA?

SELECT (customerCount + suppCount) as customers_and_suppliers_from_America
FROM
(
    SELECT  count(DISTINCT c_custkey) as customerCount
    FROM customer, nation, region
    WHERE c_nationkey = n_nationkey AND  
                n_regionkey = r_regionkey AND 
                    r_name = 'AMERICA'
), 
(
    SELECT  count(DISTINCT l_suppkey) as suppCount
    FROM lineitem, supplier, nation, region
    WHERE l_suppkey = s_suppkey AND 
            s_nationkey = n_nationkey AND 
                n_regionkey = r_regionkey AND 
                    r_name = 'AMERICA'
);