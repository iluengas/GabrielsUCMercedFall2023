import React from 'react';
import ReactDOM from 'react-dom';
// import Soccer from './soccer';
// import Banana from './banana';
import Counter from './counter'; 
//Give our functions a state that we can read off of 
import { useState, useEffect } from 'react';


import Button from '@mui/material/Button';



function App() {
  return (
    <Button >Hello world</Button>
  );
}



// function Car(){
//   const [brand, setBrand] = useState("Ford")
//   const [model, setModel] = useState("F150")
//   const [year, setYear] = useState("2000")
//   const [color, setColor] = useState("Pink")

//   return (
//     <>
//       <h1>I'm a {color} {year} {brand} {model}</h1>
//     </>
//   );
  
// }






export default App;
