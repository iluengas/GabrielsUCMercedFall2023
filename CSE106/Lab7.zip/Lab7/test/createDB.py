from myapp import db, User
#import db and user object (table) from my app

#Creates tables listed in db file 
db.create_all()