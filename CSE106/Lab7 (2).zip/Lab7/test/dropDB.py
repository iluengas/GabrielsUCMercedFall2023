from myapp import db

#Lets us delete DB **DONT RUN
db.drop_all() 